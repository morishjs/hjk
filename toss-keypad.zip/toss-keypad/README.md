# [2023 토스 NEXT 개발자 챌린지] Frontend 직군 과제테스트

## Getting started

```sh
yarn install
yarn start
```

## Testing

아래 명령어로 더미 데이터에 기반한 구현을 테스트할 수 있습니다.

```sh
yarn test
```
